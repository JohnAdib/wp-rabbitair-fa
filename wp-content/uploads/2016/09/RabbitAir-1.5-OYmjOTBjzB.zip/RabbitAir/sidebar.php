<aside class="span4">
  <?php dynamic_sidebar( 'widget-sidebar' ); ?>
  <hr class="normal-hr">
</aside>